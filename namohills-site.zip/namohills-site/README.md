# Namohills Resort — Website + Backend (Cloudflare Pages + D1)

Folder:
- public/index.html  -> website
- public/images/     -> resort photos (yahan apni ORIGINAL photos same naam se replace kar do)
- functions/api/     -> backend (bookings, client form, admin login)
- schema.sql         -> database tables
- wrangler.toml      -> Cloudflare config

## Deploy steps (ek baar)
1. npm i -g wrangler  &&  wrangler login
2. wrangler d1 create namohills-db
   -> jo database_id mile use wrangler.toml me PASTE_YOUR_DATABASE_ID_HERE ki jagah daalo
3. wrangler d1 execute namohills-db --remote --file=schema.sql
4. wrangler pages project create namohills --production-branch main
5. wrangler pages deploy public --project-name namohills
6. Admin secrets set karo (apna naya username/password rakho):
   wrangler pages secret put ADMIN_USER   --project-name namohills
   wrangler pages secret put ADMIN_PASS   --project-name namohills
   wrangler pages secret put ADMIN_SECRET --project-name namohills   (koi lamba random text)
7. Dobara deploy: wrangler pages deploy public --project-name namohills
8. Cloudflare Dashboard -> Pages -> namohills -> Custom domains -> apna GoDaddy domain add karo.

Photos badalni ho to public/images/ me same naam ki file daalo (jpg) aur step 7 dobara chalao.
